import React, { useState, useRef, useEffect } from 'react';
import DateTimePicker from '@react-native-community/datetimepicker';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  Animated,
  StyleSheet,
  Modal,
} from 'react-native';

import { Camera } from 'react-native-camera-kit';
import Feather from 'react-native-vector-icons/Feather';

import { registerProduct } from '../services/ProductApi';
import { getUserDetails } from '../services/AuthService';
import { useAppTheme } from '../services/theme';


// ============================================================
// QR PARSER
// ============================================================

const parseQR = (raw) => {
  if (!raw) return null;

  const result = {};

  const patterns = [
    {
      key: 'Device Name',
      regex: /Device Name\s*:\s*(.*?)\s*(?=Model No\s*:|$)/i,
    },
    {
      key: 'Model No',
      regex: /Model No\s*:\s*(.*?)\s*(?=Serial No\s*:|$)/i,
    },
    {
      key: 'Serial No',
      regex: /Serial No\s*:\s*(.*?)\s*(?=MAC ID\s*:|$)/i,
    },
    {
      key: 'MAC ID',
      regex: /MAC ID\s*:\s*(.*?)\s*(?=MDF By\s*:|$)/i,
    },
    {
      key: 'MDF By',
      regex: /MDF By\s*:\s*(.*)$/i,
    },
  ];

  patterns.forEach(({ key, regex }) => {
    const match = raw.match(regex);

    if (match) {
      result[key] = match[1].trim();
    }
  });

  return result;
};


// ============================================================
// EMPTY FORM
// ============================================================

const EMPTY_FORM = {
  'Device Name': '',
  'Model No': '',
  'Serial No': '',
  'MAC ID': '',
  'MDF By': '',
};


// ============================================================
// DEVICE OPTIONS
// SINGLE SOURCE OF TRUTH FOR THE DEVICE NAME DROPDOWN
// A device with a non-empty array gets a "sub-options" screen
// (e.g. WTS -> 4C/8C/12C/24C). An empty array means it is
// selectable directly with no sub-type.
// ============================================================

const DEVICE_OPTIONS = {
  WTS: ['4C', '8C', '12C', '24C'],
  TH: [],
  THO: [],
};


// ============================================================
// THRESHOLD LIMITS
// Adjust these to match your actual sensor/device range.
// ============================================================

const THRESHOLD_MIN = 0;
const THRESHOLD_MAX = 100;
const THRESHOLD_STEP = 1;


// ============================================================
// PRODUCT REGISTRATION SCREEN
// ============================================================

const ProductRegistrationScreen = ({ navigation }) => {
  const { colors } = useAppTheme();
  const styles = createStyles(colors);

  // mode: 'scan' | 'manual'
  const [mode, setMode] = useState('scan');

  const [product, setProduct] = useState(null);

  const [manualForm, setManualForm] = useState(EMPTY_FORM);

  const [showDatePicker, setShowDatePicker] = useState(false);

  const [purchaseDate, setPurchaseDate] = useState(new Date());

  const [user, setUser] = useState('');
  const [thresholdValue, setThresholdValue] = useState(String(THRESHOLD_MIN));
  const [emailEnabled, setEmailEnabled] = useState(false);
  const [smsEnabled, setSmsEnabled] = useState(false);
  const [alertEmail, setAlertEmail] = useState('');
  const [smsPhone, setSmsPhone] = useState('');
  const [location, setLocation] = useState('');

  // ==========================================================
  // DEVICE NAME DROPDOWN STATES
  // ==========================================================

  const [showDeviceDropdown, setShowDeviceDropdown] = useState(false);
  const [showSubOptions, setShowSubOptions] = useState(false);
  const [selectedParentDevice, setSelectedParentDevice] = useState(null);


  // ==========================================================
  // LOAD USER
  // ==========================================================

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const result = await getUserDetails();

      console.log(result);

      if (result?.success) {
        setUser(result.user);
      }
    } catch (e) {
      console.log('Failed to load user:', e);
    }
  };


  // ==========================================================
  // SWITCH BETWEEN SCAN / MANUAL
  // ==========================================================

  const switchMode = (newMode) => {
    if (newMode === mode) return;

    setMode(newMode);
    setProduct(null);

    setManualForm(EMPTY_FORM);

    // Close dropdowns when changing mode
    setShowDeviceDropdown(false);
    setShowSubOptions(false);
    setSelectedParentDevice(null);
  };


  // ==========================================================
  // UPDATE MANUAL FIELD
  // ==========================================================

  const updateManualField = (key, value) => {
    setManualForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  };


  // ==========================================================
  // DEVICE NAME SELECTION
  // Driven entirely by DEVICE_OPTIONS — add/remove a device or
  // its sub-types there and this logic (and the dropdown UI)
  // updates automatically, no hardcoded branches needed.
  // ==========================================================

  const selectDevice = (device) => {
    const subOptions = DEVICE_OPTIONS[device] || [];

    if (subOptions.length > 0) {
      setSelectedParentDevice(device);
      setShowDeviceDropdown(false);
      setShowSubOptions(true);
      return;
    }

    updateManualField('Device Name', device);

    setShowDeviceDropdown(false);
  };


  // ==========================================================
  // SUB-OPTION SELECTION (e.g. WTS -> 4C/8C/12C/24C)
  // ==========================================================

  const selectSubOption = (option) => {
    updateManualField('Device Name', `${selectedParentDevice} ${option}`);

    setShowSubOptions(false);
  };


  // ==========================================================
  // VALIDATE MANUAL FORM
  // ==========================================================

  const onManualSubmit = () => {
    const required = [
      'Device Name',
      'Model No',
      'Serial No',
      'MAC ID',
    ];

    const missing = required.filter(
      (key) =>
        !manualForm[key] ||
        !manualForm[key].trim()
    );

    if (missing.length > 0) {
      Alert.alert(
        'Missing Fields',
        `Please fill: ${missing.join(', ')}`
      );

      return;
    }

    // Trim all values before saving
    const cleaned = {};

    Object.keys(manualForm).forEach((key) => {
      cleaned[key] = manualForm[key].trim();
    });

    setProduct(cleaned);
  };


  // ==========================================================
  // THRESHOLD STEPPER
  // ==========================================================

  const clampThreshold = (val) => {
    if (isNaN(val)) return THRESHOLD_MIN;

    return Math.min(
      THRESHOLD_MAX,
      Math.max(THRESHOLD_MIN, val)
    );
  };

  const incrementThreshold = () => {
    const current = parseFloat(thresholdValue) || 0;

    const next = clampThreshold(current + THRESHOLD_STEP);

    setThresholdValue(String(next));
  };

  const decrementThreshold = () => {
    const current = parseFloat(thresholdValue) || 0;

    const next = clampThreshold(current - THRESHOLD_STEP);

    setThresholdValue(String(next));
  };

  const onThresholdBlur = () => {
    const current = parseFloat(thresholdValue);

    setThresholdValue(String(clampThreshold(current)));
  };


  // ==========================================================
  // REGISTER PRODUCT
  // ==========================================================

  const onRegister = async () => {
    if (!user) {
      Alert.alert(
        'Please wait',
        'User information is loading.'
      );

      return;
    }

    const body = {
      firebase_uid: user.firebase_uid,

      user_name: user.name,

      email: user.email,

      contact: user.contact,

      device_name: product['Device Name'],

      model_no: product['Model No'],

      serial_no: product['Serial No'],

      mac_id: product['MAC ID'],

      purchase_date: purchaseDate
        .toISOString()
        .split('T')[0],

      location: location.trim(),

      threshold_value: parseFloat(thresholdValue),

      email_enabled: emailEnabled,

      alert_email: alertEmail,

      sms_enabled: smsEnabled,

      sms_phone: smsPhone,
    };

    try {
      const response = await registerProduct(body);

      if (response.success) {
        Alert.alert(
          'Success',
          response.message,
          [
            {
              text: 'OK',
              onPress: () => navigation.goBack(),
            },
          ]
        );
      } else {
        Alert.alert(
          'Error',
          response.message
        );
      }
    } catch (e) {
      Alert.alert(
        'Error',
        'Unable to connect to server.'
      );
    }
  };


  // ==========================================================
  // SCAN ANIMATION
  // ==========================================================

  const scanAnimation =
    useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(scanAnimation, {
          toValue: 240,
          duration: 1800,
          useNativeDriver: true,
        }),

        Animated.timing(scanAnimation, {
          toValue: 0,
          duration: 1800,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);


  // ==========================================================
  // QR CODE READ
  // ==========================================================

  const onReadCode = (event) => {
    const qrData =
      event.nativeEvent.codeStringValue;

    const parsed = parseQR(qrData);

    if (!parsed) {
      Alert.alert('Invalid QR Code');
      return;
    }

    setProduct(parsed);
  };


  // ==========================================================
  // DATE CHANGE
  // ==========================================================

  const onDateChange = (event, selectedDate) => {
    setShowDatePicker(false);

    if (selectedDate) {
      setPurchaseDate(selectedDate);
    }
  };


  // ==========================================================
  // RENDER
  // ==========================================================

  return (
    <SafeAreaView style={styles.container}>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >

        {/* ================================================== */}
        {/* TITLE */}
        {/* ================================================== */}

        <Text style={styles.screenTitle}>
          Register Product
        </Text>

        <Text style={styles.screenSubtitle}>
          Scan a device QR code or enter its details manually
        </Text>


        {/* ================================================== */}
        {/* MODE TOGGLE */}
        {/* ================================================== */}

        <View style={styles.modeToggleContainer}>

          {/* SCAN */}

          <TouchableOpacity
            style={[
              styles.modeButton,
              mode === 'scan' &&
                styles.modeButtonActive,
            ]}
            activeOpacity={0.85}
            onPress={() => switchMode('scan')}
          >

            <Feather
              name="camera"
              size={15}
              color={
                mode === 'scan'
                  ? colors.text
                  : colors.subText
              }
              style={styles.modeIcon}
            />

            <Text
              style={[
                styles.modeButtonText,
                mode === 'scan' &&
                  styles.modeButtonTextActive,
              ]}
            >
              Scan QR
            </Text>

          </TouchableOpacity>


          {/* MANUAL */}

          <TouchableOpacity
            style={[
              styles.modeButton,
              mode === 'manual' &&
                styles.modeButtonActive,
            ]}
            activeOpacity={0.85}
            onPress={() => switchMode('manual')}
          >

            <Feather
              name="edit-3"
              size={15}
              color={
                mode === 'manual'
                  ? colors.text
                  : colors.subText
              }
              style={styles.modeIcon}
            />

            <Text
              style={[
                styles.modeButtonText,
                mode === 'manual' &&
                  styles.modeButtonTextActive,
              ]}
            >
              Enter Manually
            </Text>

          </TouchableOpacity>

        </View>


        {/* ================================================== */}
        {/* SCANNER */}
        {/* ================================================== */}

        {mode === 'scan' && !product && (

          <View style={styles.scannerContainer}>

            <View style={styles.cameraBox}>

              <Camera
                style={styles.camera}
                scanBarcode={true}
                onReadCode={onReadCode}
              />

              <Animated.View
                style={[
                  styles.scanLine,
                  {
                    transform: [
                      {
                        translateY:
                          scanAnimation,
                      },
                    ],
                  },
                ]}
              />

              <View
                style={[
                  styles.corner,
                  styles.topLeft,
                ]}
              />

              <View
                style={[
                  styles.corner,
                  styles.topRight,
                ]}
              />

              <View
                style={[
                  styles.corner,
                  styles.bottomLeft,
                ]}
              />

              <View
                style={[
                  styles.corner,
                  styles.bottomRight,
                ]}
              />

            </View>

            <Text style={styles.scanText}>
              Align QR code inside the frame
            </Text>

          </View>
        )}


        {/* ================================================== */}
        {/* MANUAL ENTRY FORM */}
        {/* ================================================== */}

        {mode === 'manual' && !product && (

          <View style={styles.card}>

            <Text style={styles.cardTitle}>
              Enter Product Details
            </Text>


            {/* ================================================== */}
            {/* DEVICE NAME DROPDOWN */}
            {/* ================================================== */}

            <View style={styles.fieldGroup}>

              <Text style={styles.inputLabel}>
                Device Name *
              </Text>

              <TouchableOpacity
                style={styles.dropdownButton}
                activeOpacity={0.85}
                onPress={() =>
                  setShowDeviceDropdown(true)
                }
              >

                <Text
                  style={[
                    styles.dropdownText,
                    !manualForm['Device Name'] && {
                      color: colors.subText,
                    },
                  ]}
                >
                  {manualForm['Device Name'] ||
                    'Select Device'}
                </Text>

                <Feather
                  name="chevron-down"
                  size={18}
                  color={colors.subText}
                />

              </TouchableOpacity>

            </View>


            {/* ================================================== */}
            {/* MODEL NO - UNCHANGED */}
            {/* ================================================== */}

            <View style={styles.fieldGroup}>

              <Text style={styles.inputLabel}>
                Model No *
              </Text>

              <TextInput
                style={styles.input}
                placeholder="e.g. RX-200-IN"
                placeholderTextColor={
                  colors.subText
                }
                autoCapitalize="characters"
                value={
                  manualForm['Model No']
                }
                onChangeText={(text) =>
                  updateManualField(
                    'Model No',
                    text
                  )
                }
              />

            </View>


            {/* ================================================== */}
            {/* SERIAL NO - UNCHANGED */}
            {/* ================================================== */}

            <View style={styles.fieldGroup}>

              <Text style={styles.inputLabel}>
                Serial No *
              </Text>

              <TextInput
                style={styles.input}
                placeholder="e.g. SN123456789"
                placeholderTextColor={
                  colors.subText
                }
                autoCapitalize="characters"
                value={
                  manualForm['Serial No']
                }
                onChangeText={(text) =>
                  updateManualField(
                    'Serial No',
                    text
                  )
                }
              />

            </View>


            {/* ================================================== */}
            {/* MAC ID - UNCHANGED */}
            {/* ================================================== */}

            <View style={styles.fieldGroup}>

              <Text style={styles.inputLabel}>
                MAC ID *
              </Text>

              <TextInput
                style={styles.input}
                placeholder="e.g. AA:BB:CC:DD:EE:FF"
                placeholderTextColor={
                  colors.subText
                }
                autoCapitalize="characters"
                value={
                  manualForm['MAC ID']
                }
                onChangeText={(text) =>
                  updateManualField(
                    'MAC ID',
                    text
                  )
                }
              />

            </View>


            {/* ================================================== */}
            {/* MANUFACTURER */}
            {/* ================================================== */}

            <View
              style={[
                styles.fieldGroup,
                { marginBottom: 4 },
              ]}
            >

              <Text style={styles.inputLabel}>
                Manufacturer (optional)
              </Text>

              <TextInput
                style={styles.input}
                placeholder="e.g. ABC Electronics"
                placeholderTextColor={
                  colors.subText
                }
                value={
                  manualForm['MDF By']
                }
                onChangeText={(text) =>
                  updateManualField(
                    'MDF By',
                    text
                  )
                }
              />

            </View>


            {/* ================================================== */}
            {/* CONTINUE */}
            {/* ================================================== */}

            <TouchableOpacity
              style={styles.registerButton}
              activeOpacity={0.85}
              onPress={onManualSubmit}
            >

              <Text style={styles.registerButtonText}>
                Continue
              </Text>

              <Feather
                name="arrow-right"
                size={16}
                color="#fff"
              />

            </TouchableOpacity>

          </View>
        )}


        {/* ================================================== */}
        {/* DEVICE NAME DROPDOWN MODAL */}
        {/* Rendered dynamically from DEVICE_OPTIONS — adding, */}
        {/* removing, or renaming a device only requires editing */}
        {/* the DEVICE_OPTIONS object above. */}
        {/* ================================================== */}

        <Modal
          visible={showDeviceDropdown}
          transparent={true}
          animationType="fade"
          onRequestClose={() =>
            setShowDeviceDropdown(false)
          }
        >

          <TouchableOpacity
            style={styles.dropdownOverlay}
            activeOpacity={1}
            onPress={() =>
              setShowDeviceDropdown(false)
            }
          >

            <TouchableOpacity
              activeOpacity={1}
              style={[
                styles.dropdownMenu,
                {
                  backgroundColor:
                    colors.card,
                },
              ]}
            >

              <Text style={styles.dropdownTitle}>
                Select Device
              </Text>

              {Object.entries(DEVICE_OPTIONS).map(
                ([device, subOptions]) => {
                  const hasSubOptions =
                    subOptions.length > 0;

                  const isSelected =
                    !hasSubOptions &&
                    manualForm['Device Name'] ===
                      device;

                  return (
                    <TouchableOpacity
                      key={device}
                      style={styles.dropdownOption}
                      activeOpacity={0.8}
                      onPress={() =>
                        selectDevice(device)
                      }
                    >

                      <Text
                        style={[
                          styles.dropdownOptionText,
                          {
                            color: colors.text,
                          },
                        ]}
                      >
                        {device}
                      </Text>

                      <Feather
                        name={
                          hasSubOptions
                            ? 'chevron-right'
                            : 'check'
                        }
                        size={18}
                        color={
                          hasSubOptions
                            ? colors.subText
                            : isSelected
                            ? '#22C55E'
                            : 'transparent'
                        }
                      />

                    </TouchableOpacity>
                  );
                }
              )}

            </TouchableOpacity>

          </TouchableOpacity>

        </Modal>


        {/* ================================================== */}
        {/* SUB-OPTIONS MODAL (e.g. WTS 4C/8C/12C/24C) */}
        {/* Options come from DEVICE_OPTIONS[selectedParentDevice] */}
        {/* ================================================== */}

        <Modal
          visible={showSubOptions}
          transparent={true}
          animationType="fade"
          onRequestClose={() =>
            setShowSubOptions(false)
          }
        >

          <TouchableOpacity
            style={styles.dropdownOverlay}
            activeOpacity={1}
            onPress={() =>
              setShowSubOptions(false)
            }
          >

            <TouchableOpacity
              activeOpacity={1}
              style={[
                styles.dropdownMenu,
                {
                  backgroundColor:
                    colors.card,
                },
              ]}
            >

              {/* HEADER */}

              <View style={styles.dropdownHeader}>

                <TouchableOpacity
                  onPress={() => {
                    setShowSubOptions(false);
                    setShowDeviceDropdown(true);
                  }}
                >

                  <Feather
                    name="arrow-left"
                    size={20}
                    color={colors.text}
                  />

                </TouchableOpacity>

                <Text
                  style={[
                    styles.dropdownTitle,
                    {
                      paddingHorizontal: 0,
                      paddingVertical: 0,
                    },
                  ]}
                >
                  Select {selectedParentDevice} Type
                </Text>

              </View>

              {(
                DEVICE_OPTIONS[selectedParentDevice] ||
                []
              ).map((option) => {
                const fullName = `${selectedParentDevice} ${option}`;

                const isSelected =
                  manualForm['Device Name'] ===
                  fullName;

                return (
                  <TouchableOpacity
                    key={option}
                    style={styles.dropdownOption}
                    activeOpacity={0.8}
                    onPress={() =>
                      selectSubOption(option)
                    }
                  >

                    <Text
                      style={[
                        styles.dropdownOptionText,
                        {
                          color: colors.text,
                        },
                      ]}
                    >
                      {fullName}
                    </Text>

                    <Feather
                      name="check"
                      size={18}
                      color={
                        isSelected
                          ? '#22C55E'
                          : 'transparent'
                      }
                    />

                  </TouchableOpacity>
                );
              })}

            </TouchableOpacity>

          </TouchableOpacity>

        </Modal>


        {/* ================================================== */}
        {/* PRODUCT DETAILS */}
        {/* ================================================== */}

        {product && (

          <View style={styles.card}>

            <View style={styles.cardTitleRow}>

              <Text style={styles.cardTitle}>
                Product Details
              </Text>

              <Feather
                name="check-circle"
                size={16}
                color="#22C55E"
              />

            </View>


            <Row
              label="Device Name"
              value={product['Device Name']}
              styles={styles}
            />

            <Row
              label="Model No"
              value={product['Model No']}
              styles={styles}
            />

            <Row
              label="Serial No"
              value={product['Serial No']}
              styles={styles}
            />

            <Row
              label="MAC ID"
              value={product['MAC ID']}
              styles={styles}
            />

            <Row
              label="Manufacturer"
              value={product['MDF By']}
              last
              styles={styles}
            />


            {/* EDIT / RESCAN */}

            <TouchableOpacity
              style={styles.editLinkRow}
              onPress={() => {

                if (mode === 'manual') {

                  setManualForm({
                    ...EMPTY_FORM,
                    ...product,
                  });

                }

                setProduct(null);
              }}
            >

              <Feather
                name={
                  mode === 'scan'
                    ? 'refresh-cw'
                    : 'edit-3'
                }
                size={14}
                color="#4F46E5"
              />

              <Text style={styles.editLink}>
                {mode === 'scan'
                  ? 'Scan Again'
                  : 'Edit Details'}
              </Text>

            </TouchableOpacity>

          </View>

        )}


        {/* ================================================== */}
        {/* PURCHASE DATE */}
        {/* ================================================== */}

        {product && (

          <View style={styles.card}>

            <Text style={styles.cardTitle}>
              Purchase Date
            </Text>

            <TouchableOpacity
              style={styles.dateButton}
              activeOpacity={0.85}
              onPress={() =>
                setShowDatePicker(true)
              }
            >

              <Feather
                name="calendar"
                size={16}
                color={colors.subText}
              />

              <Text style={styles.dateText}>
                {purchaseDate.toLocaleDateString()}
              </Text>

            </TouchableOpacity>


            {showDatePicker && (

              <DateTimePicker
                value={purchaseDate}
                mode="date"
                display="default"
                onChange={onDateChange}
              />

            )}

          </View>

        )}


        {/* ================================================== */}
        {/* LOCATION */}
        {/* ================================================== */}

        {product && (

          <View style={styles.card}>

            <Text style={styles.cardTitle}>
              Location
            </Text>

            <View
              style={[
                styles.fieldGroup,
                { marginBottom: 0 },
              ]}
            >

              <Text style={styles.inputLabel}>
                Installation Location (optional)
              </Text>

              <View style={styles.locationInputRow}>

                <Feather
                  name="map-pin"
                  size={16}
                  color={colors.subText}
                  style={styles.locationIcon}
                />

                <TextInput
                  style={styles.locationInput}
                  placeholder="e.g. Warehouse 2, Floor 1"
                  placeholderTextColor={
                    colors.subText
                  }
                  value={location}
                  onChangeText={setLocation}
                />

              </View>

            </View>

          </View>

        )}


        {/* ================================================== */}
        {/* ALERT SETTINGS */}
        {/* ================================================== */}

        {product && (

          <View style={styles.card}>

            <Text style={styles.cardTitle}>
              Alert Settings
            </Text>

            <Text style={styles.inputLabel}>
              Threshold Value
            </Text>

            <View style={styles.stepperRow}>

              <TouchableOpacity
                style={[
                  styles.stepperButton,
                  parseFloat(thresholdValue) <=
                    THRESHOLD_MIN && {
                    opacity: 0.4,
                  },
                ]}
                activeOpacity={0.8}
                disabled={
                  parseFloat(thresholdValue) <=
                  THRESHOLD_MIN
                }
                onPress={decrementThreshold}
              >

                <Feather
                  name="minus"
                  size={18}
                  color={colors.text}
                />

              </TouchableOpacity>

              <TextInput
                style={styles.stepperInput}
                keyboardType="numeric"
                textAlign="center"
                value={thresholdValue}
                onChangeText={setThresholdValue}
                onBlur={onThresholdBlur}
              />

              <TouchableOpacity
                style={[
                  styles.stepperButton,
                  parseFloat(thresholdValue) >=
                    THRESHOLD_MAX && {
                    opacity: 0.4,
                  },
                ]}
                activeOpacity={0.8}
                disabled={
                  parseFloat(thresholdValue) >=
                  THRESHOLD_MAX
                }
                onPress={incrementThreshold}
              >

                <Feather
                  name="plus"
                  size={18}
                  color={colors.text}
                />

              </TouchableOpacity>

            </View>

            <Text style={styles.stepperHint}>
              Range: {THRESHOLD_MIN} - {THRESHOLD_MAX}
            </Text>


            {/* EMAIL */}

            <View style={{ marginTop: 20 }}>

              <TouchableOpacity
                style={styles.checkboxRow}
                onPress={() =>
                  setEmailEnabled(
                    !emailEnabled
                  )
                }
              >

                <Text style={styles.checkbox}>
                  {emailEnabled
                    ? '☑'
                    : '☐'}
                </Text>

                <Text style={styles.checkboxLabel}>
                  Email Alert
                </Text>

              </TouchableOpacity>


              {emailEnabled && (

                <TextInput
                  style={styles.input}
                  placeholder="Enter Email"
                  placeholderTextColor={
                    colors.subText
                  }
                  keyboardType="email-address"
                  value={alertEmail}
                  onChangeText={setAlertEmail}
                />

              )}

            </View>


            {/* SMS */}

            <View style={{ marginTop: 20 }}>

              <TouchableOpacity
                style={styles.checkboxRow}
                onPress={() =>
                  setSmsEnabled(
                    !smsEnabled
                  )
                }
              >

                <Text style={styles.checkbox}>
                  {smsEnabled
                    ? '☑'
                    : '☐'}
                </Text>

                <Text style={styles.checkboxLabel}>
                  SMS Alert
                </Text>

              </TouchableOpacity>


              {smsEnabled && (

                <TextInput
                  style={styles.input}
                  placeholder="Enter Phone Number"
                  placeholderTextColor={
                    colors.subText
                  }
                  keyboardType="phone-pad"
                  value={smsPhone}
                  onChangeText={setSmsPhone}
                />

              )}

            </View>

          </View>

        )}


        {/* ================================================== */}
        {/* REGISTER */}
        {/* ================================================== */}

        {product && (

          <TouchableOpacity
            style={styles.registerButton}
            activeOpacity={0.85}
            onPress={onRegister}
          >

            <Text style={styles.registerButtonText}>
              Register Product
            </Text>

            <Feather
              name="arrow-right"
              size={16}
              color="#fff"
            />

          </TouchableOpacity>

        )}

      </ScrollView>

    </SafeAreaView>
  );
};


// ============================================================
// ROW COMPONENT
// ============================================================

const Row = ({
  label,
  value,
  last,
  styles,
}) => {

  return (

    <View
      style={[
        styles.row,
        last && { marginBottom: 0 },
      ]}
    >

      <Text style={styles.label}>
        {label}
      </Text>

      <Text
        style={styles.value}
        numberOfLines={1}
      >
        {value || '-'}
      </Text>

    </View>

  );
};


// ============================================================
// EXPORT
// ============================================================

export default ProductRegistrationScreen;


// ============================================================
// STYLES
// ============================================================

const createStyles = (colors) =>
  StyleSheet.create({

    // ========================================================
    // CONTAINER
    // ========================================================

    container: {
      flex: 1,
      backgroundColor: colors.background,
    },

    scrollContent: {
      paddingHorizontal: 24,
      paddingTop: 16,
      paddingBottom: 48,
    },


    // ========================================================
    // TITLE
    // ========================================================

    screenTitle: {
      fontSize: 26,
      fontWeight: '700',
      color: colors.text,
      letterSpacing: -0.4,
    },

    screenSubtitle: {
      fontSize: 14,
      color: colors.subText,
      marginTop: 6,
      marginBottom: 28,
    },


    // ========================================================
    // MODE TOGGLE
    // ========================================================

    modeToggleContainer: {
      flexDirection: 'row',
      backgroundColor: colors.border,
      borderRadius: 14,
      padding: 4,
      marginBottom: 28,
    },

    modeButton: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 11,
      borderRadius: 11,
    },

    modeButtonActive: {
      backgroundColor: colors.card,
      shadowColor: '#0B0D12',
      shadowOffset: {
        width: 0,
        height: 3,
      },
      shadowOpacity: 0.08,
      shadowRadius: 8,
      elevation: 2,
    },

    modeIcon: {
      marginRight: 6,
    },

    modeButtonText: {
      fontSize: 13,
      fontWeight: '600',
      color: colors.subText,
    },

    modeButtonTextActive: {
      color: colors.text,
    },


    // ========================================================
    // SCANNER
    // ========================================================

    scannerContainer: {
      alignItems: 'center',
      marginBottom: 28,
    },

    cameraBox: {
      width: '100%',
      height: 300,
      borderRadius: 24,
      overflow: 'hidden',
      backgroundColor: '#0B0D12',
      borderWidth: 1,
      borderColor: colors.border,
    },

    camera: {
      width: '100%',
      height: '100%',
    },

    scanLine: {
      position: 'absolute',
      left: 20,
      right: 20,
      top: 28,
      height: 2,
      backgroundColor: '#4F46E5',
      borderRadius: 2,
    },

    corner: {
      position: 'absolute',
      width: 28,
      height: 28,
      borderColor: '#fff',
    },

    topLeft: {
      top: 20,
      left: 20,
      borderTopWidth: 2.5,
      borderLeftWidth: 2.5,
      borderTopLeftRadius: 8,
    },

    topRight: {
      top: 20,
      right: 20,
      borderTopWidth: 2.5,
      borderRightWidth: 2.5,
      borderTopRightRadius: 8,
    },

    bottomLeft: {
      bottom: 20,
      left: 20,
      borderBottomWidth: 2.5,
      borderLeftWidth: 2.5,
      borderBottomLeftRadius: 8,
    },

    bottomRight: {
      bottom: 20,
      right: 20,
      borderBottomWidth: 2.5,
      borderRightWidth: 2.5,
      borderBottomRightRadius: 8,
    },

    scanText: {
      fontSize: 13,
      fontWeight: '500',
      color: colors.subText,
      marginTop: 16,
    },


    // ========================================================
    // CARDS
    // ========================================================

    card: {
      backgroundColor: colors.card,
      borderRadius: 20,
      padding: 20,
      marginBottom: 20,
      borderWidth: 1,
      borderColor: colors.border,
      shadowColor: '#0B0D12',
      shadowOffset: {
        width: 0,
        height: 6,
      },
      shadowOpacity: 0.04,
      shadowRadius: 16,
      elevation: 1,
    },

    cardTitleRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 18,
    },

    cardTitle: {
      fontSize: 18,
      fontWeight: '600',
      color: colors.text,
      marginBottom: 18,
    },


    // ========================================================
    // MANUAL FORM
    // ========================================================

    fieldGroup: {
      marginBottom: 14,
    },

    inputLabel: {
      fontSize: 12,
      fontWeight: '600',
      color: colors.subText,
      marginBottom: 8,
      letterSpacing: 0.2,
    },

    input: {
      borderWidth: 1.5,
      borderColor: colors.border,
      backgroundColor: colors.background,
      borderRadius: 12,
      paddingHorizontal: 14,
      paddingVertical: 14,
      fontSize: 15,
      fontWeight: '500',
      color: colors.text,
    },


    // ========================================================
    // DEVICE NAME DROPDOWN
    // ========================================================

    dropdownButton: {
      borderWidth: 1.5,
      borderColor: colors.border,
      backgroundColor: colors.background,
      borderRadius: 12,
      paddingHorizontal: 14,
      paddingVertical: 14,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      minHeight: 52,
    },

    dropdownText: {
      fontSize: 15,
      fontWeight: '500',
      color: colors.text,
      flex: 1,
    },

    dropdownOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0, 0, 0, 0.45)',
      justifyContent: 'center',
      paddingHorizontal: 28,
    },

    dropdownMenu: {
      borderRadius: 18,
      padding: 8,
      maxHeight: 420,
      minWidth: '100%',
    },

    dropdownTitle: {
      fontSize: 17,
      fontWeight: '700',
      color: colors.text,
      paddingHorizontal: 14,
      paddingVertical: 14,
    },

    dropdownOption: {
      minHeight: 52,
      paddingHorizontal: 14,
      borderRadius: 12,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },

    dropdownOptionText: {
      fontSize: 15,
      fontWeight: '600',
    },

    dropdownHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingHorizontal: 14,
      paddingVertical: 12,
    },


    // ========================================================
    // PRODUCT DETAILS
    // ========================================================

    row: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 12,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: colors.border,
      marginBottom: 2,
    },

    label: {
      fontSize: 14,
      fontWeight: '400',
      color: colors.subText,
    },

    value: {
      fontSize: 14,
      fontWeight: '600',
      color: colors.text,
      maxWidth: '60%',
      textAlign: 'right',
    },


    // ========================================================
    // EDIT LINK
    // ========================================================

    editLinkRow: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      marginTop: 16,
      gap: 6,
    },

    editLink: {
      fontSize: 13,
      fontWeight: '700',
      color: '#4F46E5',
    },


    // ========================================================
    // DATE
    // ========================================================

    dateButton: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      borderWidth: 1.5,
      borderColor: colors.border,
      backgroundColor: colors.background,
      borderRadius: 12,
      paddingHorizontal: 14,
      paddingVertical: 14,
    },

    dateText: {
      fontSize: 15,
      fontWeight: '600',
      color: colors.text,
    },


    // ========================================================
    // LOCATION
    // ========================================================

    locationInputRow: {
      flexDirection: 'row',
      alignItems: 'center',
      borderWidth: 1.5,
      borderColor: colors.border,
      backgroundColor: colors.background,
      borderRadius: 12,
      paddingHorizontal: 14,
    },

    locationIcon: {
      marginRight: 8,
    },

    locationInput: {
      flex: 1,
      paddingVertical: 14,
      fontSize: 15,
      fontWeight: '500',
      color: colors.text,
    },


    // ========================================================
    // THRESHOLD STEPPER
    // ========================================================

    stepperRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 4,
    },

    stepperButton: {
      width: 44,
      height: 44,
      borderRadius: 12,
      borderWidth: 1.5,
      borderColor: colors.border,
      backgroundColor: colors.background,
      alignItems: 'center',
      justifyContent: 'center',
    },

    stepperInput: {
      flex: 1,
      marginHorizontal: 10,
      height: 44,
      borderWidth: 1.5,
      borderColor: colors.border,
      backgroundColor: colors.background,
      borderRadius: 12,
      fontSize: 16,
      fontWeight: '700',
      color: colors.text,
    },

    stepperHint: {
      fontSize: 11,
      color: colors.subText,
      marginTop: 6,
    },


    // ========================================================
    // BUTTONS
    // ========================================================

    registerButton: {
      backgroundColor: '#0B0D12',
      paddingVertical: 16,
      borderRadius: 14,
      marginTop: 4,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      shadowColor: '#0B0D12',
      shadowOffset: {
        width: 0,
        height: 8,
      },
      shadowOpacity: 0.16,
      shadowRadius: 14,
      elevation: 3,
    },

    registerButtonText: {
      color: '#fff',
      fontSize: 15,
      fontWeight: '700',
    },


    // ========================================================
    // CHECKBOX
    // ========================================================

    checkboxRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },

    checkbox: {
      fontSize: 22,
      marginRight: 10,
      color: colors.text,
    },

    checkboxLabel: {
      color: colors.text,
    },

  });